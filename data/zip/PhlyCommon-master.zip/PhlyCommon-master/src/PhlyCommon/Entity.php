<?php
namespace PhlyCommon;

interface Entity extends ArraySerializable, Validatible
{
}
