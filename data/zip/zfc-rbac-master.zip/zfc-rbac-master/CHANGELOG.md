# CHANGELOG

For changelog, please refer to the [releases](https://github.com/ZF-Commons/ZfcRbac/releases) page.
