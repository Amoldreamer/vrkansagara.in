TODO
====

* Rate limiting of submissions
  Only allow X number of submissions per Y time period, potentially throttling
  more over time. 
* Referer checking
  I think this is covered by using the Hash element, but would be good to add
  an explicit check on the referer.
