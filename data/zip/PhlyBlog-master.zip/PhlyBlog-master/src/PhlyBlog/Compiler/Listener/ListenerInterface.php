<?php
namespace PhlyBlog\Compiler\Listener;

interface ListenerInterface
{
    public function compile();
}
