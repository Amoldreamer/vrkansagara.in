TODO
====

* Refine console tool
  * Migrate to use ZF2 console tooling once available
